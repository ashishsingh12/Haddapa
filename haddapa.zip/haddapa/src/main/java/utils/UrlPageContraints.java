package utils;

public final class UrlPageContraints {

	public static final String PAGE_Haddapa_DASHBOARD = "home";
}
