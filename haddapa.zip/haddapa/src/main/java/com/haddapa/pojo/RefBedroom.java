package com.haddapa.pojo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@SuppressWarnings("serial")
@Entity
@Table(name = "haddapa_ref_bedroom_type")
public class RefBedroom  implements Serializable{
	

	public RefBedroom(){
		
	}
	public RefBedroom(Long id){
		this.id=id;
	}
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private Long id;
	
	@Column(name = "Bedroom_Type")
	private String  BedroomType;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	public String getBedroomType() {
		return BedroomType;
	}
	public void setBedroomType(String bedroomType) {
		BedroomType = bedroomType;
	}

}
