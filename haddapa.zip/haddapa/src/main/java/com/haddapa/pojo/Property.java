package com.haddapa.pojo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;



@Entity
@Table(name = "haddapa_property")
public class Property implements Serializable{
	
	private static final long serialVersionUID = 1L;

	public Property(){
		
	}
	public Property(Long id){
		this.id=id;
	}
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private Long id;
	
	@Column(name = "property_name")
	private String propertyName;
	
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"}) 
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "bedroom_id", referencedColumnName = "id")
	private RefBedroom bedroomId;
	
	@Column(name = "size")
	private String Size;
	
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"}) 
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "location_id",referencedColumnName = "id")
	private RefLocation location;
	
	@Column(name = "image")
	private String image;
	
	@Column(name = "property_rating")
	private String propertyrating;
	
	@Column(name = "comment")
	private String comment;
	
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"}) 
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "broker_id",referencedColumnName = "id" )
	private RefBroker brokerid;
	
	@JsonIgnoreProperties({"hibernateLazyInitializer", "handler"}) 
	@OneToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "property_type_id",referencedColumnName = "id" )
	private RefPropertyType propertytypeid;

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getPropertyName() {
		return propertyName;
	}
	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}
	
	public RefLocation getLocation() {
		return location;
	}
	public void setLocation(RefLocation location) {
		this.location = location;
	}
	public String getImage() {
		return image;
	}
	public void setImage(String image) {
		this.image = image;
	}
	public String getPropertyrating() {
		return propertyrating;
	}
	public void setPropertyrating(String propertyrating) {
		this.propertyrating = propertyrating;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public RefBedroom getBedroomId() {
		return bedroomId;
	}
	public void setBedroomId(RefBedroom bedroomId) {
		this.bedroomId = bedroomId;
	}
	public RefBroker getBrokerid() {
		return brokerid;
	}
	public void setBrokerid(RefBroker brokerid) {
		this.brokerid = brokerid;
	}
	public RefPropertyType getPropertytypeid() {
		return propertytypeid;
	}
	public void setPropertytypeid(RefPropertyType propertytypeid) {
		this.propertytypeid = propertytypeid;
	}



}
