package com.haddapa.pojo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@SuppressWarnings("serial")
@Entity
@Table(name = "haddapa_ref_location")
public class RefLocation implements Serializable{
	
	public RefLocation(){
		
	}
	public RefLocation(Long id){
		this.id=id;
	}
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private Long id;
	
	@Column(name = "City_Id")
	private Long CityId;
	
	@Column(name = "Location_Name")
	private String LocationName;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Long getCityId() {
		return CityId;
	}

	public void setCityId(Long cityId) {
		CityId = cityId;
	}

	public String getLocationName() {
		return LocationName;
	}

	public void setLocationName(String locationName) {
		LocationName = locationName;
	}
	
	
	

}
