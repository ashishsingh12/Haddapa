package com.haddapa.bean;


public class PropertyBean {

	private Long id;
	
	private String PropertyName;
	
	private String Bedroom;
	
	private String SQFT;
	
	private String Location;
	
	private String Image;
	
	private String PropertyRating;
	
	private String Comment;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPropertyName() {
		return PropertyName;
	}

	public void setPropertyName(String propertyName) {
		PropertyName = propertyName;
	}

	public String getBedroom() {
		return Bedroom;
	}

	public void setBedroom(String bedroom) {
		Bedroom = bedroom;
	}

	public String getSQFT() {
		return SQFT;
	}

	public void setSQFT(String sQFT) {
		SQFT = sQFT;
	}

	public String getLocation() {
		return Location;
	}

	public void setLocation(String location) {
		Location = location;
	}

	public String getImage() {
		return Image;
	}

	public void setImage(String image) {
		Image = image;
	}

	public String getPropertyRating() {
		return PropertyRating;
	}

	public void setPropertyRating(String propertyRating) {
		PropertyRating = propertyRating;
	}

	public String getComment() {
		return Comment;
	}

	public void setComment(String comment) {
		Comment = comment;
	}

	
	
	
}
