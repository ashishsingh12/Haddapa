package com.haddapa.bean;

public class SearchPropertyBean {
	
	private Long id;
	private Long propertyType;
	private Long City;
	private Long location;
	private Long Broker;
	private Long BedroomType;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Long getPropertyType() {
		return propertyType;
	}
	public void setPropertyType(Long propertyType) {
		this.propertyType = propertyType;
	}
	public Long getCity() {
		return City;
	}
	public void setCity(Long city) {
		City = city;
	}
	public Long getLocation() {
		return location;
	}
	public void setLocation(Long location) {
		this.location = location;
	}
	public Long getBroker() {
		return Broker;
	}
	public void setBroker(Long broker) {
		Broker = broker;
	}
	public Long getBedroomType() {
		return BedroomType;
	}
	public void setBedroomType(Long bedroomType) {
		BedroomType = bedroomType;
	}
	

}
