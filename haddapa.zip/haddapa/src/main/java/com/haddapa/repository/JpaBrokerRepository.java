package com.haddapa.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.haddapa.pojo.RefBroker;

public interface JpaBrokerRepository extends JpaRepository<RefBroker, Long>{

}
