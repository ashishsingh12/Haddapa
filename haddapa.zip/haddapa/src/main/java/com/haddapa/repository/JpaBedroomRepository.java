package com.haddapa.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.haddapa.pojo.RefBedroom;

public interface JpaBedroomRepository  extends JpaRepository<RefBedroom, Long>{

}
