package com.haddapa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.haddapa.pojo.Property;
import com.haddapa.pojo.RefBedroom;
import com.haddapa.pojo.RefBroker;
import com.haddapa.pojo.RefLocation;
import com.haddapa.pojo.RefPropertyType;

public interface JpaPropertyRepository extends JpaRepository<Property, Long> {
	
	
	List<Property> findAllByBedroomIdAndPropertytypeidAndLocation(RefBedroom bedroomId,RefPropertyType propertyTypeId,
																	RefLocation locationId);

	

}
