package com.haddapa.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.haddapa.pojo.UserPersonLogin;
import java.lang.String;

public interface JpaPersonRepository extends JpaRepository<UserPersonLogin, Long>{
	
	UserPersonLogin findByFirstnameAndPassword(String firstname,String password);

}
