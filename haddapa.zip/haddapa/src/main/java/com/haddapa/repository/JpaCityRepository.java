package com.haddapa.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.haddapa.pojo.RefCity;

public interface JpaCityRepository  extends JpaRepository<RefCity, Long>{

}
