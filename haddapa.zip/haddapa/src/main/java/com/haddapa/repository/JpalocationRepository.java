package com.haddapa.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.haddapa.pojo.RefLocation;

public interface JpalocationRepository extends JpaRepository<RefLocation, Long> {

}
