package com.haddapa.Dao;

import org.springframework.stereotype.Repository;

@Repository
public interface HaddpaDao   {

}
