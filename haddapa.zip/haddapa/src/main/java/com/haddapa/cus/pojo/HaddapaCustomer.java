package com.haddapa.cus.pojo;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.haddapa.pojo.RefCity;

@Entity
@Table(name = "haddapa_customer")
public class HaddapaCustomer implements Serializable{
	
	private static final long serialVersionUID = 1L;

	public HaddapaCustomer(){
		
	}
	public HaddapaCustomer(Long id){
		this.id=id;
	}
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id")
	private Long id;
	
	@Column(name = "Cus_Name")
	private String CusName;
	
	@Column(name = "Cus_Email")
	private String CusEmail;
	
	@Column(name = "Cus_Number")
	private String CusNumber;
	
	@Column(name = "Cus_City")
	private RefCity CusCity;
	

	@JoinColumn(name = "Cus_State",referencedColumnName = "id")
	private String CusState;
	
	@Column(name = "Cus_Property_Type")
	private String CusPropertyType;
	
	@Column(name = "Cus_Image")
	private String CusImage;

	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getCusName() {
		return CusName;
	}
	public void setCusName(String cusName) {
		CusName = cusName;
	}
	public String getCusEmail() {
		return CusEmail;
	}
	public void setCusEmail(String cusEmail) {
		CusEmail = cusEmail;
	}
	public String getCusNumber() {
		return CusNumber;
	}
	public void setCusNumber(String cusNumber) {
		CusNumber = cusNumber;
	}
	public RefCity getCusCity() {
		return CusCity;
	}
	public void setCusCity(RefCity cusCity) {
		CusCity = cusCity;
	}
	public String getCusState() {
		return CusState;
	}
	public void setCusState(String cusState) {
		CusState = cusState;
	}
	public String getCusPropertyType() {
		return CusPropertyType;
	}
	public void setCusPropertyType(String cusPropertyType) {
		CusPropertyType = cusPropertyType;
	}
	public String getCusImage() {
		return CusImage;
	}
	public void setCusImage(String cusImage) {
		CusImage = cusImage;
	}


}
