package com.haddapa;

public class HaddapaWebSecurityConfig {

}
