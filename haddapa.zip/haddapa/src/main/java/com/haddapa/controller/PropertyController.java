package com.haddapa.controller;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.orm.jpa.JpaProperties;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.haddapa.bean.PropertyBean;
import com.haddapa.bean.SearchPropertyBean;
import com.haddapa.pojo.Property;
import com.haddapa.repository.JpaBedroomRepository;
import com.haddapa.repository.JpaBrokerRepository;
import com.haddapa.repository.JpaPropertyRepository;
import com.haddapa.repository.JpaPropertyTypeRepository;
import com.haddapa.repository.JpalocationRepository;


@RestController
public class PropertyController {
	@Autowired JpaPropertyRepository jpapropertyrepository;
	
	@Autowired private  JpaBedroomRepository jpaBedroomRepository;
	
	@Autowired  private JpaPropertyTypeRepository jpaPropertyTypeRepository;
	
	@Autowired  private JpalocationRepository jpalocationRepository;
	
	@Autowired private JpaBrokerRepository jpaBrokerRepository;
	
	@PostMapping("/home")
	public List<Property> propertyType(@ModelAttribute("propertyTypeBean") SearchPropertyBean  propertyTypeBean,Model model,HttpServletResponse response,BindingResult result) {
		List<Property> proType=null;
		try {
			proType=jpapropertyrepository.findAllByBedroomIdAndPropertytypeidAndLocation(jpaBedroomRepository.getOne(propertyTypeBean.getBedroomType()), 
																			jpaPropertyTypeRepository.getOne(propertyTypeBean.getPropertyType()),
																			jpalocationRepository.getOne(propertyTypeBean.getCity()));
																			//jpaBrokerRepository.getOne(propertyTypeBean.getBroker()));
			model.addAttribute("searchproType", proType);
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return proType;
	}
}
