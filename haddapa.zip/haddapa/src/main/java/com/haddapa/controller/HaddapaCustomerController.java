package com.haddapa.controller;

import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import com.haddapa.cus.pojo.HaddapaCustomer;
import com.haddapa.pojo.Property;
import com.haddapa.repository.JpaBrokerRepository;
import com.haddapa.repository.JpaCustomerProperty;

@RestController
public class HaddapaCustomerController {
	
	@Autowired private    JpaCustomerProperty jpaCustomerProperty;
	
	@PostMapping("/CusCustomer")
	public List<HaddapaCustomer> cusType(Model model,HttpServletResponse response,BindingResult result){
		List<HaddapaCustomer> CusType=null;
		try {
			//CusType = jpaCustomerProperty.save();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return CusType;
		
	}
		
	

}
