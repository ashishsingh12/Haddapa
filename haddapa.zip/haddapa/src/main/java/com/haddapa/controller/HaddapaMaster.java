package com.haddapa.controller;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.json.JSONObject;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.util.UrlPathHelper;

import com.haddapa.pojo.RefBedroom;
import com.haddapa.pojo.RefBroker;
import com.haddapa.pojo.RefCity;
import com.haddapa.pojo.RefLocation;
import com.haddapa.pojo.RefPropertyType;
import com.haddapa.pojo.UserPersonLogin;
import com.haddapa.repository.JpaBedroomRepository;
import com.haddapa.repository.JpaBrokerRepository;
import com.haddapa.repository.JpaCityRepository;
import com.haddapa.repository.JpaPersonRepository;
import com.haddapa.repository.JpaPropertyTypeRepository;
import com.haddapa.repository.JpalocationRepository;

import utils.UrlPageContraints;


import org.springframework.ui.Model;
	
@RestController
public class HaddapaMaster {
	
	
	//private static final Logger logger = Logger.getLogger(HaddapaMaster.class);
	@Autowired HttpSession httpsession;
	
	@Autowired JpaBedroomRepository jpaBedroomRepository; 
	
	@Autowired JpaCityRepository jpaCityRepository;
	
	@Autowired JpalocationRepository jpalocationRepository;
	
	@Autowired JpaPropertyTypeRepository jpaPropertyTypeRepository;
	
	@Autowired JpaBrokerRepository jpaBrokerRepository;
	
	@RequestMapping(value="/refbedroom",method = RequestMethod.GET)
	public List<RefBedroom>  refBedroom(){
		List<RefBedroom>  refbed = null;
		try {
			refbed = jpaBedroomRepository.findAll();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return refbed;
	}
	
	

	@RequestMapping(value="/city",method = RequestMethod.GET)
	public List<RefCity>  refCity(){
		List<RefCity>  refCity = null;
		try {
			refCity = jpaCityRepository.findAll();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return refCity;
	}
	
	@RequestMapping(value="/location",method = RequestMethod.GET)
	public List<RefLocation>  refLocation(){
		List<RefLocation>  refLocation = null;
		try {
			refLocation = jpalocationRepository.findAll();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return refLocation;
	}

	
	@RequestMapping(value="/propertyType",method = RequestMethod.GET)
	public List<RefPropertyType>  refPropertyType(){
		List<RefPropertyType>  refPropertyType = null;
		try {
			refPropertyType = jpaPropertyTypeRepository.findAll();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return refPropertyType;
	}
	
	@RequestMapping(value="/broker",method = RequestMethod.GET)
	public List<RefBroker>  refBroker(){
		List<RefBroker>  refBroker = null;
		try {
			refBroker = jpaBrokerRepository.findAll();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return refBroker;
	}
	
}
