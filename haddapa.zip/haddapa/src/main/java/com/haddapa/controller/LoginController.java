package com.haddapa.controller;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.haddapa.pojo.UserPersonLogin;
import com.haddapa.repository.JpaPersonRepository;

@RestController
//@RequestMapping("/login")
public class LoginController {

	@Autowired HttpSession httpsession;
	
	@Autowired JpaPersonRepository jpaPersonRepository;

	@PostMapping(path = "/login")
	// @RequestMapping(value = "/login", method = RequestMethod.POST)
	public ResponseEntity<String>  getLogin(@RequestBody String userDetail, HttpServletResponse response,Model model){
        ResponseEntity<String> respEntity = null;
		
		try{
			JSONObject decriptData = new JSONObject(userDetail.toString());
		String username="admin";
		String password="admin";
		UserPersonLogin person = jpaPersonRepository.findByFirstnameAndPassword(username,password);
		if(person!=null) {
			response.sendRedirect("/home");
		}
		JSONObject userValidationResponse=new JSONObject();
		userValidationResponse.put("response", "sucsess");
		respEntity = new ResponseEntity<String>((userValidationResponse.toString()), HttpStatus.OK);
		
		}catch(Exception e){
			e.printStackTrace();
			}
		
		return respEntity;
	}

}
