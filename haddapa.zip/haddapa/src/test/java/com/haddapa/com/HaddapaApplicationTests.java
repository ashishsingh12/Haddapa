package com.haddapa.com;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HaddapaApplicationTests {

	@Test
	void contextLoads() {
	}

}
